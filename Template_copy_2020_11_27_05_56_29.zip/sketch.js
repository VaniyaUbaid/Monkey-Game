
var monkey , monkey_running
var banana ,bananaImage, obstacle, obstacleImage
var FoodGroup, obstacleGroup
var score

function preload(){
  
  
  monkey_running =            loadAnimation("sprite_0.png","sprite_1.png","sprite_2.png","sprite_3.png","sprite_4.png","sprite_5.png","sprite_6.png","sprite_7.png","sprite_8.png")
  
  bananaImage = loadImage("banana.png");
  obstacleImage = loadImage("obstacle.png");
 
}



function setup() {
  
    createCanvas(600, 600);
  
 monkey = createSprite(50,180,20,50);
  
  monkey.addAnimation("running", monkey_running);
  monkey.scale = 0.1;

ground = createSprite(300,590,600,20);
  //ground.addImage("ground",groundImage);
  ground.x = ground.width /2;
  ground.velocityX = -4
  
  bananaGroup = new Group();
  obstaclesGroup = new Group();
}



function draw() {
  background ("white")
  if (ground.x < 0){
      ground.x = ground.width/2;
    }
  monkey.collide(ground)
  
  if(keyDown("space")){
      monkey.velocityY = -12;
  } 
  
    monkey.velocityY =monkey.velocityY + 0.8
  
spawnClouds();
spawnObstacles();

drawSprites()
  
}

function spawnClouds() {
  //write code here to spawn the clouds
  if (frameCount % 60 === 0) {
    var cloud = createSprite(600,120,40,10);
    cloud.y = Math.round(random(200,500));
    cloud.addImage(bananaImage);
    cloud.scale = 0.1;
    cloud.velocityX = -3;
    
     //assign lifetime to the variable
    cloud.lifetime = 200;
    
    //adjust the depth
    cloud.depth = monkey.depth;
    monkey.depth = monkey.depth + 1;
    
    //add each cloud to the group
    bananaGroup.add(cloud);
  }
  
}


function spawnObstacles() {
  if(frameCount % 60 === 0) {
    var obstacle = createSprite(600,560,10,40);
    //obstacle.debug = true;
    obstacle.velocityX = -6
    
  
     obstacle.addImage(obstacleImage);
            
    
    //assign scale and lifetime to the obstacle           
    obstacle.scale = 0.1;
    obstacle.lifetime = 300;
    //add each obstacle to the group
    obstaclesGroup.add(obstacle);
  }
}



